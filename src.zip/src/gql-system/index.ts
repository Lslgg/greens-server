export * from "./system.gql";
export * from "./system.resolver"